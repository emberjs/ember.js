export type Owner = object;
